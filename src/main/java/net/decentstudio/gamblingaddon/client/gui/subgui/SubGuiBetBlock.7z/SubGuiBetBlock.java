package ua.byby.challengesaddon.client.gui.subgui;

import com.google.common.collect.Lists;
import com.narutocraft.client.gui.subgui.SubGuiImage;
import net.minecraft.client.Minecraft;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;
import ua.byby.challengesaddon.bid.SectionColor;
import ua.byby.challengesaddon.client.gui.GuiRoulette;
import ua.byby.challengesaddon.dto.UserDTO;
import ua.byby.challengesaddon.util.GuiTextures;

import java.util.ArrayList;
import java.util.List;

public class SubGuiBetBlock extends SubGuiImage {

    private final List<String> players = Lists.newArrayList("Bob", "Ashley", "Den", "John", "Jane", "Stacy", "Rob", "Michael");

    private final SectionColor sectionColor;
    private final int fullScrollHeight;
    private final int scrollHeight;

    public int scrollOffset;
    public boolean isScrolling;
    public int startScrollingY;

    public SubGuiBetBlock(GuiRoulette parent,
                          float posX, float posY,
                          SectionColor sectionColor) {

        super(parent, sectionColor.startIdFrom(),
                posX, posY,
                0, 0,
                225, 401,
                Math.round(225 / parent.scale), Math.round(401 / parent.scale),
                225, 401,
                GuiTextures.BET_BOX);

        this.sectionColor = sectionColor;
        this.fullScrollHeight = Math.round(322 / parent.scale);
        int contentHeight = players.size() * fullScrollHeight / 6;
        scrollHeight = Math.min(fullScrollHeight, (int) (fullScrollHeight * (float)fullScrollHeight / contentHeight));
        scrollOffset = 0;
    }

    @Override
    public void initGui() {
        int index = sectionColor.startIdFrom() + 1;
        SubGuiBetButton bet = new SubGuiBetButton((GuiRoulette) parent, index++,
                posX,
                posY - 54F / ((GuiRoulette) parent).scale,
                sectionColor);

        parent.addButton(bet);
    }

    @Override
    public void draw(int mouseX, int mouseY, float partialTicks) {
        super.draw(mouseX, mouseY, partialTicks);
        drawScroll();
        handleScroll(mouseX, mouseY);
    }

    private void drawScroll() {
        int x = Math.round(this.posX + this.width + 7 / ((GuiRoulette) parent).scale);
        int y = Math.round(this.posY + 79 / ((GuiRoulette) parent).scale);
        int scrollWidth = Math.round(15 / ((GuiRoulette) parent).scale);
        int scrollBiggestPartHeight = Math.round(7 / ((GuiRoulette) parent).scale);

        GuiTextures.SCROLL_EMPTY.bind();
        drawScaledCustomSizeModalRect(x, y, 0, 0, 15, 7, scrollWidth, scrollBiggestPartHeight, 15, 15);
        drawScaledCustomSizeModalRect(x, y + scrollBiggestPartHeight, 0, 7, 15, 1, scrollWidth, fullScrollHeight - scrollBiggestPartHeight * 2, 15, 15);
        drawScaledCustomSizeModalRect(x, y + fullScrollHeight - scrollBiggestPartHeight, 0, 8, 15, 7, scrollWidth, scrollBiggestPartHeight, 15, 15);

        GuiTextures.SCROLL.bind();
        drawScaledCustomSizeModalRect(x, y + scrollOffset, 0, 0, 15, 7, scrollWidth, scrollBiggestPartHeight, 15, 15);
        drawScaledCustomSizeModalRect(x, y + scrollBiggestPartHeight + scrollOffset, 0, 7, 15, 1, scrollWidth, scrollHeight - scrollBiggestPartHeight * 2, 15, 15);
        drawScaledCustomSizeModalRect(x, y + scrollHeight - scrollBiggestPartHeight + scrollOffset, 0, 8, 15, 7, scrollWidth, scrollBiggestPartHeight, 15, 15);
    }

    private void handleScroll(int mouseX, int mouseY) {
        int x = Math.round(7 / ((GuiRoulette) parent).scale + Math.round(15 / ((GuiRoulette) parent).scale));
        if (mouseX < posX || mouseX > posX + width + x || mouseY < posY || mouseY > posY + height) {
            return;
        }

        if (isScrolling) {
            if (!Mouse.isButtonDown(0)) isScrolling = false;
            else {
                if (scrollOffset - (startScrollingY - mouseY) > fullScrollHeight + 3) {
                    scrollOffset = fullScrollHeight;
                } else if(scrollOffset - (startScrollingY - mouseY) < 0) {
                    scrollOffset = 0;
                } else {
                    if (-(startScrollingY - mouseY) != 0) {
                        scrollOffset -= (startScrollingY - mouseY);
                        startScrollingY = mouseY;
                    }
                }
            }
        }
        int wheel = Mouse.getDWheel() / 15;
        if(scrollOffset - wheel < 0) {
            scrollOffset = 0;
        }
        else if(scrollOffset - wheel > fullScrollHeight - scrollHeight) {
            scrollOffset = fullScrollHeight - scrollHeight;
        }
        else scrollOffset -= wheel;
    }
}
